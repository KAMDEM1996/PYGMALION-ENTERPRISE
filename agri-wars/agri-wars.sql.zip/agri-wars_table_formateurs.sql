
-- --------------------------------------------------------

--
-- Structure de la table `formateurs`
--
-- Création : jeu. 23 fév. 2023 à 14:19
--

DROP TABLE IF EXISTS `formateurs`;
CREATE TABLE `formateurs` (
  `idf` int(150) UNSIGNED NOT NULL COMMENT 'identifiant formateurs activé',
  `idt` int(150) UNSIGNED NOT NULL COMMENT 'identifiant formateurs non activé',
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `pseudo` varchar(50) NOT NULL,
  `pays` varchar(50) NOT NULL,
  `ville` varchar(50) NOT NULL,
  `image` text NOT NULL,
  `fichiers` text NOT NULL,
  `formation` text NOT NULL,
  `mdp` varchar(50) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='table d''activation des formateurs';

--
-- RELATIONS POUR LA TABLE `formateurs`:
--
