
-- --------------------------------------------------------

--
-- Structure de la table `free`
--
-- Création : jeu. 23 fév. 2023 à 14:35
-- Dernière modification : jeu. 23 fév. 2023 à 16:20
--

DROP TABLE IF EXISTS `free`;
CREATE TABLE `free` (
  `idf` int(150) UNSIGNED NOT NULL COMMENT 'identifiant non-actif de l''utilisateur inscrit',
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `pseudo` varchar(50) NOT NULL,
  `pays` varchar(50) NOT NULL,
  `ville` varchar(50) NOT NULL,
  `image` text NOT NULL,
  `fichiers` text NOT NULL,
  `mdp` varchar(50) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='table utilisateurs inscrits non actif';

--
-- RELATIONS POUR LA TABLE `free`:
--

--
-- Déchargement des données de la table `free`
--

INSERT INTO `free` (`idf`, `nom`, `prenom`, `contact`, `mail`, `pseudo`, `pays`, `ville`, `image`, `fichiers`, `mdp`, `time`) VALUES
(1, 'KAMDEM FOKOM', 'BISMARCK', '697276646', 'kamdemfokombismarck@gmail.com', 'gomez', 'Cameroun', 'douala', 'profile/KAMDEM FOKOM.jpg', 'recu/KAMDEM FOKOM.pdf', '25f9e794323b453885f5181f1b624d0b', '2023-02-23 16:20:46');
