
-- --------------------------------------------------------

--
-- Structure de la table `admin`
--
-- Création : jeu. 23 fév. 2023 à 14:00
-- Dernière modification : jeu. 23 fév. 2023 à 14:53
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `idAd` int(150) UNSIGNED NOT NULL COMMENT 'id administrateur',
  `NomAd` varchar(50) NOT NULL COMMENT 'nom admin',
  `PrenomAd` varchar(50) NOT NULL COMMENT 'prenom admin',
  `mdp` varchar(50) NOT NULL COMMENT 'mots de passe',
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'periode d''inscription'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='table administrateur site';

--
-- RELATIONS POUR LA TABLE `admin`:
--

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`idAd`, `NomAd`, `PrenomAd`, `mdp`, `time`) VALUES
(1, 'Kamdem Fokom', 'Bismarck', '25f9e794323b453885f5181f1b624d0b', '2023-02-23 14:53:59');
