
-- --------------------------------------------------------

--
-- Structure de la table `engins`
--
-- Création : jeu. 23 fév. 2023 à 14:09
--

DROP TABLE IF EXISTS `engins`;
CREATE TABLE `engins` (
  `id` int(150) UNSIGNED NOT NULL COMMENT 'identifiant propriétaire engins',
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `ville` varchar(50) NOT NULL,
  `engins` varchar(50) NOT NULL,
  `prixlocation` varchar(100) NOT NULL,
  `image` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='table propriétaire d''engins';

--
-- RELATIONS POUR LA TABLE `engins`:
--
