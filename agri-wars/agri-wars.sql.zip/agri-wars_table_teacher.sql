
-- --------------------------------------------------------

--
-- Structure de la table `teacher`
--
-- Création : jeu. 23 fév. 2023 à 14:31
--

DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher` (
  `idt` int(150) UNSIGNED NOT NULL COMMENT 'identifiant enseignant',
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `pseudo` varchar(50) NOT NULL,
  `pays` varchar(50) NOT NULL,
  `ville` varchar(50) NOT NULL,
  `image` text NOT NULL,
  `fichiers` text NOT NULL,
  `formation` text NOT NULL,
  `mdp` varchar(50) NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='table enseignants/formateurs';

--
-- RELATIONS POUR LA TABLE `teacher`:
--
