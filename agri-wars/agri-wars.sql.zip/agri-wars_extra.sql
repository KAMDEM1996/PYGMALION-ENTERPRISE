
--
-- Index pour les tables déchargées
--

--
-- Index pour la table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`idAd`);

--
-- Index pour la table `engins`
--
ALTER TABLE `engins`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `formateurs`
--
ALTER TABLE `formateurs`
  ADD PRIMARY KEY (`idf`),
  ADD KEY `idt` (`idt`);

--
-- Index pour la table `free`
--
ALTER TABLE `free`
  ADD PRIMARY KEY (`idf`);

--
-- Index pour la table `produit`
--
ALTER TABLE `produit`
  ADD PRIMARY KEY (`idProd`);

--
-- Index pour la table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`idt`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ids`),
  ADD KEY `idf` (`idf`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `admin`
--
ALTER TABLE `admin`
  MODIFY `idAd` int(150) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id administrateur', AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `engins`
--
ALTER TABLE `engins`
  MODIFY `id` int(150) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'identifiant propriétaire engins';

--
-- AUTO_INCREMENT pour la table `formateurs`
--
ALTER TABLE `formateurs`
  MODIFY `idf` int(150) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'identifiant formateurs activé';

--
-- AUTO_INCREMENT pour la table `free`
--
ALTER TABLE `free`
  MODIFY `idf` int(150) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'identifiant non-actif de l''utilisateur inscrit', AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `produit`
--
ALTER TABLE `produit`
  MODIFY `idProd` int(150) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'identifiant des produits';

--
-- AUTO_INCREMENT pour la table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `idt` int(150) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'identifiant enseignant';

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `ids` int(150) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'identifiant utilisateur s''étant enrégistrer et activé';
