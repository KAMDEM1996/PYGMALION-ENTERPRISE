
-- --------------------------------------------------------

--
-- Structure de la table `user`
--
-- Création : jeu. 23 fév. 2023 à 14:26
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `ids` int(150) UNSIGNED NOT NULL COMMENT 'identifiant utilisateur s''étant enrégistrer et activé',
  `idf` int(150) UNSIGNED NOT NULL COMMENT 'utilisateur s''étant juste enrégistrer',
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `pseudo` varchar(50) NOT NULL,
  `pays` varchar(50) NOT NULL,
  `ville` varchar(50) NOT NULL,
  `image` text NOT NULL,
  `fichiers` text NOT NULL,
  `mdp` varchar(50) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='table utilisateur activé';

--
-- RELATIONS POUR LA TABLE `user`:
--
