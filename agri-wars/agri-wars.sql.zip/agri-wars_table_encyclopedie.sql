
-- --------------------------------------------------------

--
-- Structure de la table `encyclopedie`
--
-- Création : jeu. 23 fév. 2023 à 14:40
--

DROP TABLE IF EXISTS `encyclopedie`;
CREATE TABLE `encyclopedie` (
  `id` int(150) NOT NULL,
  `Nom` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `Fichiers` text NOT NULL,
  `doc` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='table des encyclopedies enregistrer';

--
-- RELATIONS POUR LA TABLE `encyclopedie`:
--
