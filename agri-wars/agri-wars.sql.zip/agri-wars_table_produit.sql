
-- --------------------------------------------------------

--
-- Structure de la table `produit`
--
-- Création : jeu. 23 fév. 2023 à 14:44
--

DROP TABLE IF EXISTS `produit`;
CREATE TABLE `produit` (
  `idProd` int(150) UNSIGNED NOT NULL COMMENT 'identifiant des produits',
  `codeprod` varchar(100) NOT NULL,
  `libelle` varchar(100) NOT NULL,
  `qteprod` varchar(100) NOT NULL,
  `puprod` varchar(100) NOT NULL,
  `categorie` varchar(100) NOT NULL,
  `image` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='table des produits enrégistrer';

--
-- RELATIONS POUR LA TABLE `produit`:
--
